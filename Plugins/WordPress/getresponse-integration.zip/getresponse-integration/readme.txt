=== GetResponse Integration ===
Contributors: Kacper Rowiński
Tags: getresponse, email, newsletter, signup, marketing, plugin, widget, mailing list, subscriber, contacts, subscribe form
Requires at least: 2.8.6
Tested up to: 3.0-beta2
Stable tag: 1.0

The GetResponse Integration plugin allows you to quickly and easily add a signup form for your site.

== Description ==

The GetResponse Integration plug-in allows you to quickly and easily add a sign up form for your site.
You can configure you customs, conformation URLs and more! Its quick and easy way to add forms to you site.

== Installation ==
1. Extract all files to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to wigets and configure you plugin!

== Frequently Asked Questions ==

= How do I find my "Web from id" ? =
Your web form id can be found on you account Contacts => Web froms. There if you move cursor over "preview" 
link the last number after the ?id= code id you web from id.

== Screenshots ==

1. Some of widget options
2. GetResponse form options
3. Light box integration
4. Example form on page

== Changelog ==

= v1.0 =

* Inital release.

